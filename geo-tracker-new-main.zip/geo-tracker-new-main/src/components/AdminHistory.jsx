import { useState } from 'react';

function getDateObj(t) {
  return t?.seconds ? new Date(t.seconds * 1000) : new Date(t);
}

function copyCoords(lat, lng) {
  navigator.clipboard.writeText(`${lat.toFixed(6)}, ${lng.toFixed(6)}`)
    .then(() => alert('Coordinates copied to clipboard!'))
    .catch(() => alert(`Copy manually: ${lat.toFixed(6)}, ${lng.toFixed(6)}`));
}

function statusColor(s) {
  return s === 'Active' ? 'bg-green-100 text-green-700 border border-green-200'
    : s === 'Not Active' ? 'bg-red-100 text-red-700 border border-red-200'
    : 'bg-yellow-100 text-yellow-700 border border-yellow-200';
}

function regColor(r) {
  return r === 'Registered'
    ? 'bg-blue-100 text-blue-700 border border-blue-200'
    : 'bg-orange-100 text-orange-700 border border-orange-200';
}

export function HistCard({ d, showEmployee = true }) {
  const dateObj = getDateObj(d.time);
  const hasCoords = d.latitude && d.longitude;

  return (
    <div className="bg-white rounded-2xl border border-gray-200 shadow-sm hover:shadow-md transition-shadow duration-200 mb-4">
      <div className="flex items-start justify-between px-5 pt-5 pb-3 gap-4">
        {/* Left: info */}
        <div className="flex-1 min-w-0">
          {/* Name + status */}
          <div className="flex items-center flex-wrap gap-2 mb-2">
            <span className="text-[#0078D4] font-bold text-lg leading-tight">
              {showEmployee ? d.employee?.split('@')[0] : d.clientName}
            </span>
            <span className={`text-xs font-semibold px-2.5 py-0.5 rounded-full ${statusColor(d.orderStatus)}`}>
              {d.orderStatus}
            </span>
          </div>

          {/* Employee email */}
          {showEmployee && (
            <div className="flex items-center gap-2 text-gray-500 text-sm mb-3">
              <i className="fas fa-user text-[#0078D4] text-xs"></i>
              <span>{d.employee}</span>
            </div>
          )}

          {/* Meta row */}
          <div className="flex flex-wrap items-center gap-x-3 gap-y-1.5 bg-gray-50 rounded-xl px-4 py-2.5 text-sm text-gray-600">
            <span className="flex items-center gap-1.5">
              <i className="fas fa-map-marker-alt text-[#0078D4] text-xs"></i>
              <span className="font-medium">{d.area || '—'}</span>
            </span>
            <span className="text-gray-300 hidden sm:inline">|</span>
            <span className="flex items-center gap-1.5">
              <i className="far fa-calendar-alt text-[#0078D4] text-xs"></i>
              {dateObj.toLocaleDateString()}
            </span>
            <span className="text-gray-300 hidden sm:inline">|</span>
            <span className="flex items-center gap-1.5">
              <i className="far fa-clock text-[#0078D4] text-xs"></i>
              {dateObj.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', second: '2-digit' })}
            </span>
            <span className="text-gray-300 hidden sm:inline">|</span>
            <span className={`text-xs font-semibold px-2 py-0.5 rounded-full ${regColor(d.registered)}`}>
              <i className="fas fa-check-circle mr-1 text-[10px]"></i>
              Registered: {d.registered}
            </span>
          </div>
        </div>

        {/* Right: image + action buttons */}
        <div className="flex-shrink-0 flex flex-col items-center gap-2">
          {d.imageUrl && (
            <img
              src={d.imageUrl}
              alt="visit"
              onClick={() => window.open(d.imageUrl)}
              className="w-24 h-24 rounded-xl object-cover border border-gray-200 shadow cursor-pointer hover:scale-105 transition-transform duration-200"
            />
          )}
          {hasCoords && (
            <div className="flex gap-2">
              <a
                href={`https://www.google.com/maps?q=${d.latitude},${d.longitude}`}
                target="_blank" rel="noreferrer"
                title="Open in Google Maps"
                className="w-8 h-8 rounded-lg bg-[#0078D4] hover:bg-[#005A9E] flex items-center justify-center text-white transition-colors text-sm"
              >
                <i className="fas fa-map-marked-alt"></i>
              </a>
              <button
                onClick={() => copyCoords(d.latitude, d.longitude)}
                title="Copy Coordinates"
                className="w-8 h-8 rounded-lg bg-[#0078D4] hover:bg-[#005A9E] flex items-center justify-center text-white transition-colors text-sm"
                style={{ width: 32, padding: 0 }}
              >
                <i className="fas fa-copy"></i>
              </button>
            </div>
          )}
        </div>
      </div>

      {/* Feedback */}
      <div className="mx-5 mb-5">
        {d.feedback ? (
          <div className="bg-gray-50 border-l-4 border-[#0078D4] rounded-r-xl px-4 py-3 flex gap-2">
            <i className="fas fa-comment-dots text-[#0078D4] text-sm mt-0.5 flex-shrink-0"></i>
            <p className="text-sm text-gray-700 leading-relaxed m-0">
              <span className="font-semibold text-gray-800">Feedback: </span>{d.feedback}
            </p>
          </div>
        ) : (
          <div className="bg-gray-50 border-l-4 border-gray-200 rounded-r-xl px-4 py-2.5">
            <p className="text-sm text-gray-400 italic m-0">No feedback provided</p>
          </div>
        )}
      </div>
    </div>
  );
}

export default function AdminHistory({ masterData }) {
  const [empFilter, setEmpFilter] = useState('');
  const [dateFilter, setDateFilter] = useState('');
  const [filtered, setFiltered] = useState(null);

  const applyFilters = () => {
    const result = masterData.filter(d => {
      const dDate = new Date(d.time?.seconds ? d.time.seconds * 1000 : d.time).toISOString().split('T')[0];
      return (!dateFilter || dDate === dateFilter) && (!empFilter || d.employee?.toLowerCase().includes(empFilter.toLowerCase()));
    });
    setFiltered(result);
  };

  const resetFilters = () => { setEmpFilter(''); setDateFilter(''); setFiltered(null); };

  const displayData = [...(filtered ?? masterData)].reverse();

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-800">Historical Data</h1>
        <p className="text-gray-400 text-sm mt-1">{displayData.length} record{displayData.length !== 1 ? 's' : ''}</p>
      </div>

      {/* Filter bar */}
      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-5 py-4 mb-5 flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 flex-1 min-w-[200px] bg-gray-50 border border-gray-200 rounded-xl px-3 py-2">
          <i className="fas fa-search text-gray-400 text-sm"></i>
          <input
            type="text" value={empFilter} onChange={e => setEmpFilter(e.target.value)}
            placeholder="Search by employee email…"
            className="flex-1 bg-transparent outline-none text-sm text-gray-700 placeholder-gray-400"
            style={{ border: 'none', padding: 0, margin: 0 }}
          />
        </div>
        <div className="flex items-center gap-2 min-w-[160px] bg-gray-50 border border-gray-200 rounded-xl px-3 py-2">
          <i className="far fa-calendar text-gray-400 text-sm"></i>
          <input
            type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm text-gray-700"
            style={{ border: 'none', padding: 0, margin: 0 }}
          />
        </div>
        <button onClick={applyFilters} className="px-5 py-2 bg-[#0078D4] hover:bg-[#005A9E] text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-search mr-1.5"></i> Search
        </button>
        <button onClick={resetFilters} className="px-5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-times mr-1.5"></i> Clear
        </button>
      </div>

      {displayData.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-14 text-center">
          <i className="fas fa-folder-open text-5xl text-gray-300 mb-4 block"></i>
          <p className="text-gray-400">No records found.</p>
        </div>
      ) : displayData.map((d, i) => <HistCard key={i} d={d} showEmployee={true} />)}
    </div>
  );
}
