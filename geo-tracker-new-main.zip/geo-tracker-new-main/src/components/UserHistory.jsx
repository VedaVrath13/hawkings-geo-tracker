import { useState } from 'react';
import { HistCard } from './AdminHistory';

export default function UserHistory({ masterData, currentUser }) {
  const [dateFilter, setDateFilter] = useState('');
  const [filtered, setFiltered] = useState(null);
  const userData = masterData.filter(d => d.employee === currentUser);

  const applyFilters = () => {
    const result = userData.filter(d => {
      const dDate = new Date(d.time?.seconds ? d.time.seconds * 1000 : d.time).toISOString().split('T')[0];
      return !dateFilter || dDate === dateFilter;
    });
    setFiltered(result);
  };

  const resetFilters = () => { setDateFilter(''); setFiltered(null); };
  const displayData = [...(filtered ?? userData)].reverse();

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-800">My Visit History</h1>
        <p className="text-gray-400 text-sm mt-1">{displayData.length} visit{displayData.length !== 1 ? 's' : ''}</p>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm px-5 py-4 mb-5 flex flex-wrap gap-3 items-center">
        <div className="flex items-center gap-2 min-w-[160px] bg-gray-50 border border-gray-200 rounded-xl px-3 py-2">
          <i className="far fa-calendar text-gray-400 text-sm"></i>
          <input
            type="date" value={dateFilter} onChange={e => setDateFilter(e.target.value)}
            className="flex-1 bg-transparent outline-none text-sm text-gray-700"
            style={{ border: 'none', padding: 0, margin: 0 }}
          />
        </div>
        <button onClick={applyFilters} className="px-5 py-2 bg-[#0078D4] hover:bg-[#005A9E] text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-search mr-1.5"></i> Search
        </button>
        <button onClick={resetFilters} className="px-5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-times mr-1.5"></i> Clear
        </button>
      </div>

      {displayData.length === 0
        ? <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-12 text-center text-gray-400">No visits yet.</div>
        : displayData.map((d, i) => <HistCard key={i} d={d} showEmployee={false} />)
      }
    </div>
  );
}
