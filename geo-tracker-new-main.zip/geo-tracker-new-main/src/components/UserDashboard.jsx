import { useState } from 'react';
import * as XLSX from 'xlsx';

export default function UserDashboard({ masterData, currentUser }) {
  const userData = masterData.filter(d => d.employee === currentUser);
  const now = new Date();
  const monthData = userData.filter(d => {
    const dDate = d.time?.seconds ? new Date(d.time.seconds * 1000) : new Date(d.time);
    return dDate.getMonth() === now.getMonth() && dDate.getFullYear() === now.getFullYear();
  });

  const [fromDate, setFromDate] = useState('');
  const [toDate, setToDate] = useState('');

  const exportToExcel = () => {
    let filtered = userData;
    if (fromDate) filtered = filtered.filter(d => {
      const dDate = d.time?.seconds ? new Date(d.time.seconds * 1000) : new Date(d.time);
      return dDate >= new Date(fromDate);
    });
    if (toDate) {
      const to = new Date(toDate); to.setHours(23, 59, 59, 999);
      filtered = filtered.filter(d => {
        const dDate = d.time?.seconds ? new Date(d.time.seconds * 1000) : new Date(d.time);
        return dDate <= to;
      });
    }
    const ws = XLSX.utils.json_to_sheet(filtered);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'My Visits');
    XLSX.writeFile(wb, 'MyVisits_Report.xlsx');
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">My Dashboard</h1>
        <p className="text-gray-400 text-sm mt-1">Welcome back, {currentUser?.split('@')[0]}</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mb-6">
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#0078D4] flex items-center justify-center text-white text-lg">
            <i className="fas fa-clipboard-list"></i>
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">Total Visits</p>
            <p className="text-2xl font-bold text-gray-800">{userData.length}</p>
          </div>
        </div>
        <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex items-center gap-4">
          <div className="w-12 h-12 rounded-xl bg-[#107C10] flex items-center justify-center text-white text-lg">
            <i className="fas fa-calendar-check"></i>
          </div>
          <div>
            <p className="text-sm text-gray-500 font-medium">This Month</p>
            <p className="text-2xl font-bold text-gray-800">{monthData.length}</p>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="text-base font-bold text-gray-800 mb-4 flex items-center gap-2">
          <i className="fas fa-file-excel text-green-600"></i> Export My Data
        </h3>
        <div className="flex flex-wrap gap-3 mb-4">
          <input
            type="date" value={fromDate} onChange={e => setFromDate(e.target.value)}
            className="flex-1 min-w-[150px] border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4]"
            style={{ margin: 0 }}
          />
          <input
            type="date" value={toDate} onChange={e => setToDate(e.target.value)}
            className="flex-1 min-w-[150px] border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4]"
            style={{ margin: 0 }}
          />
        </div>
        <button onClick={exportToExcel} className="w-full bg-[#107C10] hover:bg-green-800 text-white font-semibold py-3 rounded-xl transition-colors">
          <i className="fas fa-download mr-2"></i>Download Excel Report
        </button>
      </div>
    </div>
  );
}
