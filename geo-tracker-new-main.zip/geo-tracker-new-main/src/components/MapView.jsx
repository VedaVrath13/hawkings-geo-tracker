import { useEffect, useRef } from 'react';
import { GOOGLE_MAPS_API_KEY } from '../firebase';

let googleMap = null;
let markers = [];
let mapPathLine = null;

function loadGoogleMapsScript() {
  return new Promise((resolve) => {
    if (window.google?.maps) return resolve();
    const existing = document.getElementById('gmap-script');
    if (existing) { existing.addEventListener('load', resolve); return; }
    const script = document.createElement('script');
    script.id = 'gmap-script';
    script.src = `https://maps.googleapis.com/maps/api/js?key=${GOOGLE_MAPS_API_KEY}`;
    script.async = true;
    script.onload = resolve;
    document.head.appendChild(script);
  });
}

export default function MapView({ masterData }) {
  const mapRef = useRef(null);
  const dateRef = useRef(null);
  const empRef = useRef(null);

  const initAndUpdate = async (dateVal = '', empVal = '') => {
    await loadGoogleMapsScript();
    if (!mapRef.current) return;
    if (!googleMap) {
      googleMap = new window.google.maps.Map(mapRef.current, { zoom: 5, center: { lat: 20.5937, lng: 78.9629 }, mapTypeControl: false, streetViewControl: false });
    }
    markers.forEach(m => m.setMap(null)); markers = [];
    if (mapPathLine) { mapPathLine.setMap(null); mapPathLine = null; }

    const filtered = masterData.filter(d => {
      if (!d.latitude || !d.longitude) return false;
      const dDate = new Date(d.time?.seconds ? d.time.seconds * 1000 : d.time).toISOString().split('T')[0];
      return (!dateVal || dDate === dateVal) && (!empVal || d.employee === empVal);
    });
    if (filtered.length === 0) return;

    const sorted = [...filtered].sort((a, b) => {
      const ta = a.time?.seconds ? a.time.seconds * 1000 : new Date(a.time).getTime();
      const tb = b.time?.seconds ? b.time.seconds * 1000 : new Date(b.time).getTime();
      return ta - tb;
    });

    const bounds = new window.google.maps.LatLngBounds();
    const pathCoords = [];

    sorted.forEach((d, i) => {
      const pos = { lat: d.latitude, lng: d.longitude };
      pathCoords.push(pos); bounds.extend(pos);
      const dateObj = d.time?.seconds ? new Date(d.time.seconds * 1000) : new Date(d.time);
      const empName = (d.employee || '').split('@')[0];
      const marker = new window.google.maps.Marker({
        position: pos, map: googleMap,
        label: { text: String(i + 1), color: 'white', fontWeight: 'bold', fontSize: '11px' },
        title: d.clientName,
        icon: { path: window.google.maps.SymbolPath.CIRCLE, fillColor: '#0078D4', fillOpacity: 1, strokeColor: '#005A9E', strokeWeight: 2, scale: 14 }
      });
      const infoWindow = new window.google.maps.InfoWindow({
        content: `<div style="font-family:'Segoe UI',sans-serif;min-width:180px;padding:4px">
          <b style="color:#0078D4;font-size:1rem;">#${i + 1} ‒ ${d.clientName || 'Unknown'}</b><br>
          <span style="font-size:0.8rem;color:#555;">👤 ${empName}<br>📍 ${d.area || '-'}<br>📊 ${d.orderStatus || '-'}<br>🕒 ${dateObj.toLocaleString()}</span><br>
          <a href="https://www.google.com/maps?q=${d.latitude},${d.longitude}" target="_blank" style="font-size:0.78rem;color:#0078D4;">Open in Maps ↗</a>
        </div>`
      });
      marker.addListener('click', () => infoWindow.open(googleMap, marker));
      markers.push(marker);
    });

    if (sorted.length > 1 && (dateVal || empVal)) {
      mapPathLine = new window.google.maps.Polyline({
        path: pathCoords, geodesic: true, strokeColor: '#0078D4', strokeOpacity: 0.8, strokeWeight: 4,
        icons: [{ icon: { path: window.google.maps.SymbolPath.FORWARD_CLOSED_ARROW, scale: 3, strokeColor: '#005A9E' }, offset: '100%', repeat: '80px' }]
      });
      mapPathLine.setMap(googleMap);
    }
    googleMap.fitBounds(bounds);
    if (filtered.length === 1) googleMap.setZoom(15);
  };

  useEffect(() => { googleMap = null; if (masterData.length > 0) initAndUpdate('', ''); }, [masterData]);

  const emps = [...new Set(masterData.map(d => d.employee))];

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-800">Live Field Tracking</h1>
        <p className="text-gray-400 text-sm mt-1">Real-time visit locations on the map</p>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-5">
        {/* Filters */}
        <div className="flex flex-wrap gap-3 mb-4 items-end">
          <div className="flex-1 min-w-[150px]">
            <label className="block text-xs font-semibold text-gray-500 mb-1">DATE</label>
            <input type="date" ref={dateRef} className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4]" style={{ margin: 0 }} />
          </div>
          <div className="flex-1 min-w-[160px]">
            <label className="block text-xs font-semibold text-gray-500 mb-1">EMPLOYEE</label>
            <select ref={empRef} className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4]" style={{ margin: 0 }}>
              <option value="">All Employees</option>
              {emps.map(e => <option key={e} value={e}>{e}</option>)}
            </select>
          </div>
          <div className="flex gap-2">
            <button onClick={() => initAndUpdate(dateRef.current.value, empRef.current.value)} className="px-5 py-2 bg-[#0078D4] hover:bg-[#005A9E] text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
              🔍 Search
            </button>
            <button onClick={() => { dateRef.current.value = ''; empRef.current.value = ''; initAndUpdate('', ''); }} className="px-5 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
              ✕ Clear
            </button>
          </div>
        </div>
        <p className="text-xs text-gray-400 mb-3">
          <i className="fas fa-info-circle mr-1 text-[#0078D4]"></i>
          Filter by date to see the timed visit path with arrows. All pins shown by default.
        </p>
        <div id="map" ref={mapRef} className="rounded-xl border border-gray-200"></div>
      </div>
    </div>
  );
}
