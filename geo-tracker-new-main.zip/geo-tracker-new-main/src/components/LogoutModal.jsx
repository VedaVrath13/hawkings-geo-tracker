import { signOut } from 'firebase/auth';
import { auth } from '../firebase';

export default function LogoutModal({ open, onClose }) {
  const confirmLogout = () => signOut(auth).then(() => window.location.reload());

  if (!open) return null;

  return (
    <div className="fixed inset-0 z-[2000] bg-black/50 flex items-center justify-center">
      <div className="bg-white rounded-2xl p-8 w-[90%] max-w-sm text-center shadow-2xl">
        <div className="w-14 h-14 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-4">
          <i className="fas fa-sign-out-alt text-[#A4262C] text-xl"></i>
        </div>
        <h3 className="text-lg font-bold text-gray-800 mb-1">Confirm Logout</h3>
        <p className="text-gray-500 text-sm mb-6">Are you sure you want to end your session?</p>
        <div className="flex gap-3">
          <button
            onClick={onClose}
            className="flex-1 py-2.5 bg-gray-100 hover:bg-gray-200 text-gray-700 font-semibold rounded-xl transition-colors"
            style={{ width: 'auto' }}
          >
            Cancel
          </button>
          <button
            onClick={confirmLogout}
            className="flex-1 py-2.5 bg-[#A4262C] hover:bg-red-800 text-white font-semibold rounded-xl transition-colors"
            style={{ width: 'auto' }}
          >
            Logout
          </button>
        </div>
      </div>
    </div>
  );
}
