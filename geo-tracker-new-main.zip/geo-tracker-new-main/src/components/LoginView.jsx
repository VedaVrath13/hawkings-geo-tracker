import { signInWithEmailAndPassword } from 'firebase/auth';
import { useState } from 'react';
import { auth } from '../firebase';

export default function LoginView() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !password) return alert('Please enter email and password.');
    setLoading(true);
    try {
      await signInWithEmailAndPassword(auth, email, password);
    } catch (e) {
      alert(e.message);
    }
    setLoading(false);
  };

  return (
    <div className="w-full max-w-sm">
      <div className="bg-white rounded-2xl shadow-lg p-8">
        <div className="text-center mb-6">
          <div className="w-14 h-14 bg-[#0078D4] rounded-full flex items-center justify-center mx-auto mb-3">
            <i className="fas fa-shield-alt text-white text-xl"></i>
          </div>
          <h2 className="text-2xl font-bold text-gray-800">Secure Login</h2>
          <p className="text-gray-400 text-sm mt-1">Sign in to ZennX Tracker</p>
        </div>
        <div className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Email</label>
            <div className="flex items-center gap-2 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-[#0078D4] transition-colors">
              <i className="fas fa-envelope text-gray-400 text-sm"></i>
              <input
                type="email"
                value={email}
                onChange={e => setEmail(e.target.value)}
                placeholder="you@example.com"
                className="flex-1 outline-none text-sm text-gray-700 bg-transparent"
                style={{ border: 'none', padding: 0, margin: 0, width: '100%' }}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
              />
            </div>
          </div>
          <div>
            <label className="block text-sm font-medium text-gray-600 mb-1">Password</label>
            <div className="flex items-center gap-2 border border-gray-200 rounded-xl px-3 py-2.5 focus-within:border-[#0078D4] transition-colors">
              <i className="fas fa-lock text-gray-400 text-sm"></i>
              <input
                type="password"
                value={password}
                onChange={e => setPassword(e.target.value)}
                placeholder="••••••••"
                className="flex-1 outline-none text-sm text-gray-700 bg-transparent"
                style={{ border: 'none', padding: 0, margin: 0, width: '100%' }}
                onKeyDown={e => e.key === 'Enter' && handleLogin()}
              />
            </div>
          </div>
          <button
            onClick={handleLogin}
            disabled={loading}
            className="w-full bg-[#0078D4] hover:bg-[#005A9E] disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors duration-150 mt-2"
            style={{ width: '100%' }}
          >
            {loading ? <><i className="fas fa-spinner fa-spin mr-2"></i>Signing in…</> : 'Login'}
          </button>
        </div>
      </div>
    </div>
  );
}
