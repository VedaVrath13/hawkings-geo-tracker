import { useState, useRef } from 'react';
import { db, storage } from '../firebase';
import { addDoc, collection } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

export default function AdminNewVisit({ currentUser, onLogout }) {
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);
  const [locText, setLocText] = useState('Location not set');
  const [submitting, setSubmitting] = useState(false);
  const [summary, setSummary] = useState('');
  const [showSummary, setShowSummary] = useState(false);

  const clientNameRef = useRef();
  const zidRef = useRef();
  const areaRef = useRef();
  const regRef = useRef();
  const statusRef = useRef();
  const feedbackRef = useRef();
  const selfieRef = useRef();

  const getLocation = () => {
    navigator.geolocation.getCurrentPosition(
      p => {
        setLat(p.coords.latitude);
        setLng(p.coords.longitude);
        setLocText(`Captured: ${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`);
      },
      () => alert('Please enable GPS')
    );
  };

  const submitVisit = async () => {
    const file = selfieRef.current.files[0];
    if (!lat || !lng || !file) return alert('Missing GPS or Photo!');
    setSubmitting(true);
    try {
      const sRef = ref(storage, `v/${Date.now()}`);
      await uploadBytes(sRef, file);
      const url = await getDownloadURL(sRef);
      const visitDate = new Date();
      const visitData = {
        employee: currentUser,
        clientName: clientNameRef.current.value,
        zid: zidRef.current.value || 'N/A',
        area: areaRef.current.value,
        registered: regRef.current.value,
        orderStatus: statusRef.current.value,
        feedback: feedbackRef.current.value,
        latitude: lat,
        longitude: lng,
        imageUrl: url,
        time: visitDate
      };
      await addDoc(collection(db, 'visits'), visitData);
      const waText =
        `📍 *Visit Update*\n\n` +
        ` *Employee:* ${currentUser}\n` +
        ` *Client:* ${clientNameRef.current.value}\n` +
        ` *ZID:* ${zidRef.current.value || 'N/A'}\n` +
        ` *Area:* ${areaRef.current.value}\n` +
        ` *Status:* ${statusRef.current.value}\n` +
        ` *Feedback:* ${feedbackRef.current.value || '-'}\n` +
        ` *Time:* ${visitDate.toLocaleString()}\n` +
        `📌 *Location:* https://www.google.com/maps?q=${lat},${lng}`;
      setSummary(waText);
      setShowSummary(true);
      alert('Report Saved!');
    } catch (e) {
      alert('Error: ' + e.message);
    }
    setSubmitting(false);
  };

  const copyVisitText = () => {
    navigator.clipboard.writeText(summary);
    alert('Copied to clipboard!');
  };

  return (
    <div>
      <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
        <h1>Field Report</h1>
        <button onClick={onLogout} style={{ width: 'auto', background: 'none', color: 'var(--danger)' }}>Logout</button>
      </div>
      <div className="card">
        <input type="text" ref={clientNameRef} placeholder="Client Name" />
        <input type="text" ref={zidRef} placeholder="ZID (Optional)" />
        <input type="text" ref={areaRef} placeholder="Area" />
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap' }}>
          <select ref={regRef} style={{ flex: 1 }}>
            <option>Registered</option>
            <option>Not Registered</option>
          </select>
          <select ref={statusRef} style={{ flex: 1 }}>
            <option>Active</option>
            <option>Not Active</option>
            <option>Occasional</option>
          </select>
        </div>
        <textarea ref={feedbackRef} placeholder="Feedback/Notes"></textarea>
        <div style={{ display: 'flex', gap: 10, flexWrap: 'wrap', marginBottom: 10 }}>
          <button onClick={getLocation} style={{ background: '#f8f9fa', color: 'var(--primary)', border: '1px solid var(--border)', flex: 1, minWidth: 150 }}>
            📍 Capture GPS
          </button>
        </div>
        <p style={{ textAlign: 'center', fontSize: '0.8rem' }}>{locText}</p>
        <input type="file" ref={selfieRef} accept="image/*" />
        <button onClick={submitVisit} disabled={submitting}>
          {submitting ? 'Uploading...' : 'Submit Report ✅'}
        </button>
      </div>
      {showSummary && (
        <div className="card" style={{ background: '#eef' }}>
          <h4 style={{ marginTop: 0 }}>📋 Visit Summary</h4>
          <textarea rows="7" readOnly style={{ background: 'white' }} value={summary}></textarea>
          <button onClick={copyVisitText} style={{ background: '#25D366' }}>
            <i className="fab fa-whatsapp"></i> Copy for WhatsApp
          </button>
        </div>
      )}
    </div>
  );
}
