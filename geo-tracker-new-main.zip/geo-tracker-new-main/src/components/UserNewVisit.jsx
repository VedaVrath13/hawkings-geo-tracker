import { useState } from 'react';
import { db, storage } from '../firebase';
import { addDoc, collection } from 'firebase/firestore';
import { ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const inputCls = "w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#0078D4] transition-colors bg-white";

export default function UserNewVisit({ currentUser, onLogout, onDraftSaved }) {
  const [clientName, setClientName] = useState('');
  const [zid, setZid] = useState('');
  const [area, setArea] = useState('');
  const [reg, setReg] = useState('Registered');
  const [status, setStatus] = useState('Active');
  const [feedback, setFeedback] = useState('');
  const [lat, setLat] = useState(null);
  const [lng, setLng] = useState(null);
  const [locText, setLocText] = useState('Location not set');
  const [submitting, setSubmitting] = useState(false);
  const [selfieFile, setSelfieFile] = useState(null);

  const getLocation = () => {
    navigator.geolocation.getCurrentPosition(
      p => { setLat(p.coords.latitude); setLng(p.coords.longitude); setLocText(`Captured: ${p.coords.latitude.toFixed(4)}, ${p.coords.longitude.toFixed(4)}`); },
      () => alert('Please enable GPS')
    );
  };

  const resetForm = () => {
    setClientName(''); setZid(''); setArea('');
    setReg('Registered'); setStatus('Active'); setFeedback('');
    setLat(null); setLng(null); setSelfieFile(null); setLocText('Location not set');
  };

  const handleSubmit = async () => {
    if (!lat || !lng) return alert('Missing GPS! Please capture location first.');
    if (!clientName.trim()) return alert('Please enter Client Name!');
    setSubmitting(true);
    try {
      let imageUrl = '';
      if (selfieFile) {
        const sRef = ref(storage, `drafts/${Date.now()}`);
        await uploadBytes(sRef, selfieFile);
        imageUrl = await getDownloadURL(sRef);
      }
      await addDoc(collection(db, 'drafts'), { employee: currentUser, clientName, zid: zid || 'N/A', area, registered: reg, orderStatus: status, feedback, latitude: lat, longitude: lng, imageUrl, status: 'draft' });
      resetForm();
      alert('Saved to Drafts! Go to Drafts page to edit and publish.');
      if (onDraftSaved) onDraftSaved();
    } catch (e) { alert('Error: ' + e.message); }
    setSubmitting(false);
  };

  return (
    <div>
      <div className="flex items-center justify-between mb-6">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">New Visit</h1>
          <p className="text-gray-400 text-sm mt-1">Fill in details and capture GPS</p>
        </div>
        <button onClick={onLogout} className="text-[#A4262C] text-sm font-semibold hover:underline bg-transparent border-none cursor-pointer" style={{ width: 'auto', background: 'none', color: '#A4262C' }}>
          <i className="fas fa-sign-out-alt mr-1"></i> Logout
        </button>
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6 space-y-3">
        <input type="text" value={clientName} onChange={e => setClientName(e.target.value)} placeholder="Client Name *" className={inputCls} style={{ margin: 0 }} />
        <input type="text" value={zid} onChange={e => setZid(e.target.value)} placeholder="ZID (Optional)" className={inputCls} style={{ margin: 0 }} />
        <input type="text" value={area} onChange={e => setArea(e.target.value)} placeholder="Area" className={inputCls} style={{ margin: 0 }} />

        <div className="flex gap-3">
          <select value={reg} onChange={e => setReg(e.target.value)} className={`flex-1 ${inputCls}`} style={{ margin: 0 }}>
            <option>Registered</option>
            <option>Not Registered</option>
          </select>
          <select value={status} onChange={e => setStatus(e.target.value)} className={`flex-1 ${inputCls}`} style={{ margin: 0 }}>
            <option>Active</option>
            <option>Not Active</option>
            <option>Occasional</option>
          </select>
        </div>

        <textarea value={feedback} onChange={e => setFeedback(e.target.value)} placeholder="Feedback / Notes" rows={3} className={inputCls} style={{ margin: 0, resize: 'vertical' }} />

        <button onClick={getLocation} type="button" className="w-full border border-[#0078D4] text-[#0078D4] bg-blue-50 hover:bg-blue-100 font-semibold py-2.5 rounded-xl transition-colors text-sm">
          <i className="fas fa-map-marker-alt mr-2"></i>📍 Capture GPS
        </button>

        <p className={`text-center text-xs font-medium ${lat ? 'text-green-600' : 'text-gray-400'}`}>
          {lat ? <><i className="fas fa-check-circle mr-1"></i>{locText}</> : locText}
        </p>

        <div>
          <label className="block text-xs text-gray-500 font-medium mb-1">Upload Photo (optional)</label>
          <input type="file" accept="image/*" onChange={e => setSelfieFile(e.target.files[0])} className="w-full text-sm text-gray-500 file:mr-3 file:py-1.5 file:px-4 file:rounded-lg file:border-0 file:text-sm file:font-semibold file:bg-blue-50 file:text-[#0078D4] hover:file:bg-blue-100 cursor-pointer" style={{ border: 'none', padding: 0, margin: 0 }} />
        </div>

        <button onClick={handleSubmit} disabled={submitting} className="w-full bg-[#0078D4] hover:bg-[#005A9E] disabled:opacity-60 text-white font-semibold py-3 rounded-xl transition-colors mt-2">
          {submitting ? <><i className="fas fa-spinner fa-spin mr-2"></i>Saving…</> : <><i className="fas fa-save mr-2"></i>Save to Drafts</>}
        </button>
      </div>
    </div>
  );
}
