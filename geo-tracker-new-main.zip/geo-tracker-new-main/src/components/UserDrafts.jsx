import { useState } from 'react';
import { db } from '../firebase';
import { addDoc, collection, deleteDoc, doc, updateDoc } from 'firebase/firestore';

const inputCls = "w-full border border-gray-200 rounded-xl px-3 py-2.5 text-sm outline-none focus:border-[#0078D4] transition-colors bg-white";

function DraftCard({ d, onRefresh }) {
  const [editing, setEditing] = useState(false);
  const [clientName, setClientName] = useState(d.clientName || '');
  const [zid, setZid] = useState(d.zid || '');
  const [area, setArea] = useState(d.area || '');
  const [reg, setReg] = useState(d.registered || 'Registered');
  const [status, setStatus] = useState(d.orderStatus || 'Active');
  const [feedback, setFeedback] = useState(d.feedback || '');

  const saveDraftEdit = async () => {
    try {
      await updateDoc(doc(db, 'drafts', d.id), { clientName, zid: zid || 'N/A', area, registered: reg, orderStatus: status, feedback });
      alert('Draft updated!'); setEditing(false); onRefresh();
    } catch (e) { alert('Error saving: ' + e.message); }
  };

  const publishDraft = async () => {
    if (!confirm('Publish this draft? It will be submitted to the admin.')) return;
    try {
      const visitData = { ...d }; delete visitData.id; delete visitData.status; delete visitData.savedAt;
      visitData.time = new Date();
      await addDoc(collection(db, 'visits'), visitData);
      await deleteDoc(doc(db, 'drafts', d.id));
      alert('Published successfully!'); onRefresh();
    } catch (e) { alert('Error publishing: ' + e.message); }
  };

  const deleteDraft = async () => {
    if (!confirm('Delete this draft permanently?')) return;
    try { await deleteDoc(doc(db, 'drafts', d.id)); alert('Draft deleted.'); onRefresh(); }
    catch (e) { alert('Error deleting: ' + e.message); }
  };

  return (
    <div className="bg-white rounded-2xl border-l-4 border-l-amber-400 border border-amber-200 shadow-sm mb-4 p-5">
      {/* Header */}
      <div className="flex items-center gap-2 mb-3">
        <span className="text-[#0078D4] font-bold text-lg">{d.clientName || 'Unnamed'}</span>
        <span className="bg-amber-100 text-amber-700 text-xs font-bold px-2.5 py-0.5 rounded-full border border-amber-200">Draft</span>
      </div>

      {/* Meta row */}
      <div className="flex flex-wrap gap-3 mb-3 text-sm text-gray-600">
        <span className="flex items-center gap-1.5 bg-gray-50 rounded-lg px-3 py-1.5">
          <i className="fas fa-map-marker-alt text-[#0078D4] text-xs"></i>{d.area || '—'}
        </span>
        <span className="flex items-center gap-1.5 bg-gray-50 rounded-lg px-3 py-1.5">
          <i className="fas fa-tag text-[#0078D4] text-xs"></i>{d.registered || '—'}
        </span>
        <span className="flex items-center gap-1.5 bg-gray-50 rounded-lg px-3 py-1.5">
          <i className="fas fa-circle-dot text-[#0078D4] text-xs"></i>{d.orderStatus || '—'}
        </span>
      </div>

      {/* Coords link */}
      {d.latitude && d.longitude && (
        <a href={`https://www.google.com/maps?q=${d.latitude},${d.longitude}`} target="_blank" rel="noreferrer"
          className="flex items-center gap-2 mb-3 px-3 py-2.5 bg-blue-50 border border-blue-200 rounded-xl text-sm text-[#0078D4] font-semibold no-underline hover:bg-blue-100 transition-colors">
          <i className="fas fa-location-dot"></i>
          <span>{d.latitude.toFixed(5)}, {d.longitude.toFixed(5)}</span>
          <span className="ml-auto text-xs opacity-70">View on Map ↗</span>
        </a>
      )}

      {/* Feedback */}
      <div className="bg-gray-50 border-l-4 border-gray-200 rounded-r-xl px-4 py-2.5 mb-3 text-sm text-gray-600">
        <b className="text-gray-700">Feedback: </b>{d.feedback || <span className="italic text-gray-400">No feedback</span>}
      </div>

      {/* Photo */}
      {d.imageUrl ? (
        <img src={d.imageUrl} onClick={() => window.open(d.imageUrl)} alt="photo"
          className="w-full max-w-[180px] h-28 object-cover rounded-xl border border-gray-200 cursor-pointer hover:scale-105 transition-transform mb-3" />
      ) : (
        <p className="text-xs text-gray-400 italic mb-3">No photo attached</p>
      )}

      {/* Actions */}
      <div className="flex gap-2 flex-wrap">
        <button onClick={() => setEditing(!editing)} className="flex-1 min-w-[90px] py-2 bg-[#0078D4] hover:bg-[#005A9E] text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-edit mr-1.5"></i>Edit
        </button>
        <button onClick={publishDraft} className="flex-1 min-w-[90px] py-2 bg-[#107C10] hover:bg-green-800 text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-paper-plane mr-1.5"></i>Publish
        </button>
        <button onClick={deleteDraft} className="flex-1 min-w-[90px] py-2 bg-[#A4262C] hover:bg-red-800 text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
          <i className="fas fa-trash mr-1.5"></i>Delete
        </button>
      </div>

      {/* Edit form */}
      {editing && (
        <div className="mt-4 pt-4 border-t border-gray-100 space-y-3">
          <h4 className="font-bold text-[#0078D4] text-sm mb-2">Edit Draft</h4>
          <input type="text" value={clientName} onChange={e => setClientName(e.target.value)} placeholder="Client Name" className={inputCls} style={{ margin: 0 }} />
          <input type="text" value={zid} onChange={e => setZid(e.target.value)} placeholder="ZID (Optional)" className={inputCls} style={{ margin: 0 }} />
          <input type="text" value={area} onChange={e => setArea(e.target.value)} placeholder="Area" className={inputCls} style={{ margin: 0 }} />
          <div className="flex gap-3">
            <select value={reg} onChange={e => setReg(e.target.value)} className={`flex-1 ${inputCls}`} style={{ margin: 0 }}>
              <option>Registered</option><option>Not Registered</option>
            </select>
            <select value={status} onChange={e => setStatus(e.target.value)} className={`flex-1 ${inputCls}`} style={{ margin: 0 }}>
              <option>Active</option><option>Not Active</option><option>Occasional</option>
            </select>
          </div>
          <textarea value={feedback} onChange={e => setFeedback(e.target.value)} placeholder="Feedback/Notes" rows={3} className={inputCls} style={{ margin: 0 }} />
          <div className="flex gap-2">
            <button onClick={saveDraftEdit} className="flex-1 py-2 bg-[#107C10] hover:bg-green-800 text-white text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
              <i className="fas fa-save mr-1.5"></i>Save Changes
            </button>
            <button onClick={() => setEditing(false)} className="flex-1 py-2 bg-gray-100 hover:bg-gray-200 text-gray-700 text-sm font-semibold rounded-xl transition-colors" style={{ width: 'auto' }}>
              Cancel
            </button>
          </div>
        </div>
      )}
    </div>
  );
}

export default function UserDrafts({ draftsData, currentUser, onRefresh }) {
  const myDrafts = draftsData.filter(d => d.employee === currentUser);

  return (
    <div>
      <div className="mb-5">
        <h1 className="text-2xl font-bold text-gray-800">My Drafts</h1>
        <p className="text-amber-600 text-sm mt-1 flex items-center gap-1.5">
          <i className="fas fa-info-circle"></i>
          Drafts are only visible to you. Edit and publish when ready.
        </p>
      </div>

      {myDrafts.length === 0 ? (
        <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-14 text-center">
          <i className="fas fa-file-alt text-5xl text-gray-300 mb-4 block"></i>
          <p className="text-gray-500 font-medium">No drafts yet</p>
          <p className="text-gray-400 text-sm mt-1">New visits are saved here for review before publishing.</p>
        </div>
      ) : (
        myDrafts.map(d => <DraftCard key={d.id} d={d} onRefresh={onRefresh} />)
      )}
    </div>
  );
}
