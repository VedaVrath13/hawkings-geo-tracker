import { useState } from 'react';
import * as XLSX from 'xlsx';

function StatCard({ label, value, icon, color }) {
  return (
    <div className="bg-white rounded-2xl p-5 border border-gray-100 shadow-sm flex items-center gap-4">
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center text-white text-lg ${color}`}>
        <i className={icon}></i>
      </div>
      <div>
        <p className="text-sm text-gray-500 font-medium">{label}</p>
        <p className="text-2xl font-bold text-gray-800">{value}</p>
      </div>
    </div>
  );
}

export default function AdminDashboard({ masterData }) {
  const total = masterData.length;
  const active = masterData.filter(d => d.orderStatus === 'Active').length;
  const newReg = masterData.filter(d => d.registered === 'Not Registered').length;
  const emps = [...new Set(masterData.map(d => d.employee))];

  const [expFrom, setExpFrom] = useState('');
  const [expTo, setExpTo] = useState('');
  const [expEmp, setExpEmp] = useState('all');

  const exportToExcel = () => {
    let filtered = masterData;
    if (expEmp !== 'all') filtered = filtered.filter(d => d.employee === expEmp);
    if (expFrom) filtered = filtered.filter(d => {
      const dDate = d.time?.seconds ? new Date(d.time.seconds * 1000) : new Date(d.time);
      return dDate >= new Date(expFrom);
    });
    if (expTo) {
      const to = new Date(expTo);
      to.setHours(23, 59, 59, 999);
      filtered = filtered.filter(d => {
        const dDate = d.time?.seconds ? new Date(d.time.seconds * 1000) : new Date(d.time);
        return dDate <= to;
      });
    }
    const rows = filtered.map(d => ({
      'Date': d.time?.seconds ? new Date(d.time.seconds * 1000).toLocaleDateString() : '',
      'Employee': d.employee || '', 'Client Name': d.clientName || '',
      'ZID': d.zid || '', 'Area': d.area || '',
      'Registered': d.registered || '', 'Status': d.orderStatus || '',
      'Feedback': d.feedback || '',
      'Latitude': (d.latitude || '').toString(),
      'Longitude': (d.longitude || '').toString()
    }));
    const ws = XLSX.utils.json_to_sheet(rows);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Visits');
    XLSX.writeFile(wb, 'ZennX_Report.xlsx');
  };

  return (
    <div>
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-800">Operational Analytics</h1>
        <p className="text-gray-400 text-sm mt-1">Overview of all field visits</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mb-6">
        <StatCard label="Total Visits" value={total} icon="fas fa-clipboard-list" color="bg-[#0078D4]" />
        <StatCard label="Active Clients" value={active} icon="fas fa-check-circle" color="bg-[#107C10]" />
        <StatCard label="New Registrations" value={newReg} icon="fas fa-user-plus" color="bg-amber-500" />
      </div>

      <div className="bg-white rounded-2xl border border-gray-100 shadow-sm p-6">
        <h3 className="text-base font-bold text-gray-800 mb-4 flex items-center gap-2">
          <i className="fas fa-file-excel text-green-600"></i> Export Data
        </h3>
        <div className="flex flex-wrap gap-3 mb-4">
          <input
            type="date" value={expFrom} onChange={e => setExpFrom(e.target.value)}
            className="flex-1 min-w-[150px] border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4] transition-colors"
            style={{ margin: 0 }}
          />
          <input
            type="date" value={expTo} onChange={e => setExpTo(e.target.value)}
            className="flex-1 min-w-[150px] border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4] transition-colors"
            style={{ margin: 0 }}
          />
        </div>
        <select
          value={expEmp} onChange={e => setExpEmp(e.target.value)}
          className="w-full border border-gray-200 rounded-xl px-3 py-2 text-sm outline-none focus:border-[#0078D4] transition-colors mb-4"
          style={{ margin: 0 }}
        >
          <option value="all">All Employees</option>
          {emps.map(e => <option key={e} value={e}>{e}</option>)}
        </select>
        <button
          onClick={exportToExcel}
          className="w-full bg-[#107C10] hover:bg-green-800 text-white font-semibold py-3 rounded-xl transition-colors"
        >
          <i className="fas fa-download mr-2"></i>Download Excel Report
        </button>
      </div>
    </div>
  );
}
