import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage";
import { getAuth } from "firebase/auth";

const firebaseConfig = {
  apiKey: "AIzaSyCsrbo7GREULX86jlYb12b-Wij1Dtg3sMI",
  authDomain: "zennx-tracker-6ec45.firebaseapp.com",
  projectId: "zennx-tracker-6ec45",
  storageBucket: "zennx-tracker-6ec45.firebasestorage.app",
  messagingSenderId: "174189895680",
  appId: "1:174189895680:web:d51337f120b6438e7cf8e5"
};

const app = initializeApp(firebaseConfig);
export const db = getFirestore(app);
export const storage = getStorage(app);
export const auth = getAuth(app);

export const ADMIN_EMAILS = ["zennx.usm@gmail.com", "saisnd70@gmail.com"];
export const GOOGLE_MAPS_API_KEY = "AIzaSyAhAIRN38f0GpLTaMZ9dKUGGZhDmUmwZhU";
