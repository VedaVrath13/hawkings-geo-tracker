import { useState, useEffect, useCallback } from 'react';
import { onAuthStateChanged } from 'firebase/auth';
import { getDocs, collection, query, orderBy } from 'firebase/firestore';
import { auth, db, ADMIN_EMAILS } from './firebase';

import LoginView from './components/LoginView';
import LogoutModal from './components/LogoutModal';
import AdminDashboard from './components/AdminDashboard';
import AdminHistory from './components/AdminHistory';
import MapView from './components/MapView';
import UserDashboard from './components/UserDashboard';
import UserNewVisit from './components/UserNewVisit';
import UserDrafts from './components/UserDrafts';
import UserHistory from './components/UserHistory';

function NavItem({ icon, label, active, onClick, danger }) {
  return (
    <div
      onClick={onClick}
      className={`flex items-center gap-4 px-6 py-3.5 cursor-pointer font-medium transition-all duration-150 select-none
        ${active
          ? 'bg-blue-50 text-[#0078D4] border-l-4 border-[#0078D4]'
          : danger
            ? 'text-[#A4262C] hover:bg-red-50'
            : 'text-gray-500 hover:bg-gray-50 hover:text-gray-700'
        }`}
    >
      <i className={`${icon} w-4 text-center`}></i>
      <span>{label}</span>
    </div>
  );
}

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [isAdmin, setIsAdmin] = useState(false);
  const [activeView, setActiveView] = useState('login');
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const [logoutModalOpen, setLogoutModalOpen] = useState(false);
  const [masterData, setMasterData] = useState([]);
  const [draftsData, setDraftsData] = useState([]);

  const loadData = useCallback(async (user) => {
    const u = user || currentUser;
    if (!u) return;
    const snap = await getDocs(query(collection(db, 'visits'), orderBy('time', 'asc')));
    const visits = [];
    snap.forEach(d => visits.push(d.data()));
    setMasterData(visits);

    const dSnap = await getDocs(collection(db, 'drafts'));
    const drafts = [];
    dSnap.forEach(d => drafts.push({ id: d.id, ...d.data() }));
    setDraftsData(drafts);
  }, [currentUser]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, (user) => {
      if (user) {
        setCurrentUser(user.email);
        const admin = ADMIN_EMAILS.includes(user.email);
        setIsAdmin(admin);
        setActiveView(admin ? 'dashboard' : 'userDashboard');
        loadData(user.email);
      } else {
        setCurrentUser(null);
        setIsAdmin(false);
        setActiveView('login');
      }
    });
    return () => unsub();
  }, []);

  const switchView = (view) => {
    setActiveView(view);
    setSidebarOpen(false);
    if (view !== 'login') loadData();
  };

  const myDraftsCount = draftsData.filter(d => d.employee === currentUser).length;

  if (!currentUser) {
    return (
      <div className="min-h-screen bg-[#F3F2F1] flex items-center justify-center p-6">
        <LoginView />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#F3F2F1] flex font-[Segoe_UI,sans-serif]">

      {/* Mobile Top Bar */}
      <div className="top-bar fixed top-0 left-0 right-0 h-[60px] bg-[#0078D4] text-white items-center px-4 z-[900] shadow-md hidden">
        <i className="fas fa-bars text-2xl cursor-pointer mr-4" onClick={() => setSidebarOpen(s => !s)}></i>
        <span className="font-semibold">ZennX Tracker</span>
      </div>

      {/* Overlay */}
      {sidebarOpen && (
        <div
          className="fixed inset-0 bg-black/40 z-[1000]"
          onClick={() => setSidebarOpen(false)}
        />
      )}

      {/* Sidebar */}
      <nav className={`sidebar ${sidebarOpen ? 'open' : ''}`} style={{ display: 'flex' }}>
        {/* Header */}
        <div className="flex items-center justify-between px-6 py-5 border-b border-gray-100 text-[#0078D4]">
          <span className="font-bold text-base flex items-center gap-2">
            <i className={isAdmin ? 'fas fa-shield-alt' : 'fas fa-user-circle'}></i>
            ZennX {isAdmin ? 'Admin' : 'User'}
          </span>
          <i className="fas fa-times cursor-pointer text-gray-400 hover:text-gray-700" onClick={() => setSidebarOpen(false)}></i>
        </div>

        {/* Nav items */}
        <div className="flex-1 overflow-y-auto py-2">
          {isAdmin ? (
            <>
              <NavItem icon="fas fa-th-large" label="Dashboard" active={activeView === 'dashboard'} onClick={() => switchView('dashboard')} />
              <NavItem icon="fas fa-history" label="Master History" active={activeView === 'history'} onClick={() => switchView('history')} />
              <NavItem icon="fas fa-map-marked-alt" label="Live Tracking" active={activeView === 'map'} onClick={() => switchView('map')} />
            </>
          ) : (
            <>
              <NavItem icon="fas fa-th-large" label="Dashboard" active={activeView === 'userDashboard'} onClick={() => switchView('userDashboard')} />
              <NavItem icon="fas fa-plus-circle" label="New Visit" active={activeView === 'userNewVisit'} onClick={() => switchView('userNewVisit')} />
              <NavItem icon="fas fa-history" label="Visit History" active={activeView === 'userHistory'} onClick={() => switchView('userHistory')} />
              <NavItem
                icon="fas fa-file-alt"
                active={activeView === 'userDrafts'}
                onClick={() => switchView('userDrafts')}
                label={
                  <span className="flex items-center gap-1.5">
                    Drafts
                    {myDraftsCount > 0 && (
                      <span className="bg-amber-500 text-white text-[10px] font-bold px-2 py-0.5 rounded-full">{myDraftsCount}</span>
                    )}
                  </span>
                }
              />
            </>
          )}
        </div>

        {/* Logout */}
        <div className="border-t border-gray-100">
          <NavItem icon="fas fa-sign-out-alt" label="Logout" danger onClick={() => setLogoutModalOpen(true)} />
        </div>
      </nav>

      {/* Main content */}
      <main className="main-content flex-1 p-6 transition-all duration-300" style={{ marginLeft: 260 }}>
        {isAdmin && activeView === 'dashboard' && <AdminDashboard masterData={masterData} />}
        {isAdmin && activeView === 'history' && <AdminHistory masterData={masterData} />}
        {isAdmin && activeView === 'map' && <MapView masterData={masterData} />}

        {!isAdmin && activeView === 'userDashboard' && <UserDashboard masterData={masterData} currentUser={currentUser} />}
        {!isAdmin && activeView === 'userNewVisit' && <UserNewVisit currentUser={currentUser} onLogout={() => setLogoutModalOpen(true)} onDraftSaved={loadData} />}
        {!isAdmin && activeView === 'userHistory' && <UserHistory masterData={masterData} currentUser={currentUser} />}
        {!isAdmin && activeView === 'userDrafts' && <UserDrafts draftsData={draftsData} currentUser={currentUser} onRefresh={loadData} />}
      </main>

      <LogoutModal open={logoutModalOpen} onClose={() => setLogoutModalOpen(false)} />
    </div>
  );
}
